# Network Science Project
## Main code
save in main algorithm folder
## Data set
1. save in main algorithm/Dataset/ folder
2. The data set does not contain the detail information, so I treat it just like a test file
## Graphs
save in the _Graphs and Loge_ folder
